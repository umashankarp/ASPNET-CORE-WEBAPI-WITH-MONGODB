export const environment = {
  production: true,
  apiUrl: 'https://cfcapi2021test.azurewebsites.net/'
};
