export class CustomerLogin {
    userName: string;
    password: string;
}