export class CustomerRegistration {
    name: string;
    email: string;
    mobileNo: string;
    password: string
}