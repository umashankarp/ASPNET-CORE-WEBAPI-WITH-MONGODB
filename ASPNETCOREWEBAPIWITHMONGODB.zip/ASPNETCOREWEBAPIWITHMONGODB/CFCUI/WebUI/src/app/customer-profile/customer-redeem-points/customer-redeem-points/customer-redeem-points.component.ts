import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-redeem-points',
  templateUrl: './customer-redeem-points.component.html',
  styleUrls: ['./customer-redeem-points.component.css']
})
export class CustomerRedeemPointsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
