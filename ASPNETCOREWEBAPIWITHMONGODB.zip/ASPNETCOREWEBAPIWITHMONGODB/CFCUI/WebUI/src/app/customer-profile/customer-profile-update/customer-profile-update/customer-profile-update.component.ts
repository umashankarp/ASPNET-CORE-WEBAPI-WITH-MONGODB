import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-profile-update',
  templateUrl: './customer-profile-update.component.html',
  styleUrls: ['./customer-profile-update.component.css']
})
export class CustomerProfileUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
