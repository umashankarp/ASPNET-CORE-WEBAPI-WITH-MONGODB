export const environment = {
  production: true,
  apiUrl : 'https://recyclingforrewardsboapi20210728174246.azurewebsites.net/api/',
  imageURL : 'https://cfcimages.blob.core.windows.net/cfcimages/'
};
