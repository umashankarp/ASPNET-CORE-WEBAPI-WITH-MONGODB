export class approverejectdata
{
    id: string;
    approved: boolean;
    comment: string;
    finalRecycleValue: number;
  }