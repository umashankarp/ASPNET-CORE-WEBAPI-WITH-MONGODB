export class recycleRequest {
    Id: number;
    RequestNo: number;
    RequestDate :string;
    ModelVariant : string;
    finalRecycleValue: number;
    MaxRecycleValue: number;
    Status : string;
    ReviewedBy : string;
    ReviewedOn : string ;
    PhysicallyVerifiedBy : string;
    PhysicallyVerifiedOn : string ;
}