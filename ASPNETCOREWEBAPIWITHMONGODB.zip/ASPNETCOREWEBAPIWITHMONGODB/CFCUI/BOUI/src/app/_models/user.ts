﻿export class User {
    name: string;
    userName: string;
    email: string;
    mobileNo: string;
    role: string;
    isActive: string;
    token?: string;
}