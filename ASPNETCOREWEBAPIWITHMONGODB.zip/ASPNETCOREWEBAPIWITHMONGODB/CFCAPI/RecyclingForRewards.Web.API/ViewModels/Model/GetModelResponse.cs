﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RecyclingForRewards.Web.API.ViewModels.Model
{
    public class GetModelResponse
    {
        public string Id { get; set; }
        public string ModelName { get; set; }
        public string ModelImageName { get; set; }
    }
}
