﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RecyclingForRewards.Web.API.ViewModels.RecycleRequest
{
    public class CreateRecycleRequestResponse
    {
        public string RequestNo { get; set; }
    }

}
